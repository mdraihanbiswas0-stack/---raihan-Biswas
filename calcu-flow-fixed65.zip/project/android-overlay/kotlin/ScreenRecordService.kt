package com.earflow.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.*
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.IntentCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.min

class ScreenRecordService : Service() {
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var recorder: MediaRecorder? = null
    private var pointer: PointerView? = null
    private var countView: TextView? = null
    private var paused = false
    private var outFile: File? = null
    private var active = false
    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        when (intent?.action) {
            "START" -> {
                fg()
                val code = intent.getIntExtra("code", 0)
                val data = IntentCompat.getParcelableExtra(intent, "data", Intent::class.java)
                if (data == null) { stopSelf(); return START_NOT_STICKY }
                val p = getSharedPreferences("ef", MODE_PRIVATE)
                if (p.getBoolean("countdown", true) && Settings.canDrawOverlays(this)) countdown(3) { capture(code, data) }
                else capture(code, data)
            }
            "PAUSE" -> togglePause()
            "STOP" -> stopAll()
        }
        return START_NOT_STICKY
    }

    private fun pi(action: String) = PendingIntent.getService(this, action.hashCode(),
        Intent(this, ScreenRecordService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE)

    private fun notif(): Notification {
        return NotificationCompat.Builder(this, "scr")
            .setContentTitle(if (paused) "রেকর্ডিং বিরতিতে" else "স্ক্রিন রেকর্ড হচ্ছে")
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true)
            .addAction(0, if (paused) "চালু" else "বিরতি", pi("PAUSE"))
            .addAction(0, "বন্ধ", pi("STOP")).build()
    }

    private fun fg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("scr", "Screen recorder", NotificationManager.IMPORTANCE_LOW))
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        startForeground(2, notif(), type)
    }

    private fun overlay(w: Int, hh: Int, touchable: Boolean) = WindowManager.LayoutParams(
        w, hh, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT).apply { gravity = if (touchable) Gravity.TOP or Gravity.START else Gravity.CENTER }

    private fun countdown(n: Int, done: () -> Unit) {
        if (countView == null) {
            val tv = TextView(this).apply { textSize = 96f; setTextColor(Color.WHITE); setShadowLayer(12f, 0f, 0f, Color.BLACK) }
            countView = tv
            wm.addView(tv, overlay(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, false))
        }
        if (n == 0) {
            countView?.let { wm.removeView(it) }
            countView = null
            h.postDelayed({ done() }, 150)
            return
        }
        countView?.text = n.toString()
        h.postDelayed({ countdown(n - 1, done) }, 1000)
    }

    @Suppress("DEPRECATION")
    private fun capture(code: Int, data: Intent) {
        val p = getSharedPreferences("ef", MODE_PRIVATE)
        val dm = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
        val q = p.getInt("quality", 1080)
        val scale = if (q == 0) 1f else min(1f, q.toFloat() / min(dm.widthPixels, dm.heightPixels))
        val w = (dm.widthPixels * scale).toInt() / 2 * 2
        val hh = (dm.heightPixels * scale).toInt() / 2 * 2
        val mic = p.getBoolean("mic", true) &&
            checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

        val dir = File(getExternalFilesDir(null), "videos").apply { mkdirs() }
        val f = File(dir, "EarFlow_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4")

        outFile = f
        try {
            recorder = MediaRecorder().apply {
                if (mic) setAudioSource(MediaRecorder.AudioSource.MIC)
                setVideoSource(MediaRecorder.VideoSource.SURFACE)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setOutputFile(f.absolutePath)
                setVideoEncoder(MediaRecorder.VideoEncoder.H264)   // হার্ডওয়্যার এনকোডার = ল্যাগ-ফ্রি
                setVideoSize(w, hh)
                setVideoFrameRate(p.getInt("fps", 60))
                setVideoEncodingBitRate(p.getInt("bitrate", 16) * 1_000_000)
                if (mic) {
                    setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    setAudioEncodingBitRate(128000); setAudioSamplingRate(44100)
                }
                prepare()
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mpm.getMediaProjection(code, data).apply {
                registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { stopAll() }
                }, h)
            }
            vd = projection!!.createVirtualDisplay("EarFlow", w, hh, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder!!.surface, null, h)
            recorder!!.start()
            active = true
            if (p.getBoolean("dot", true) && Settings.canDrawOverlays(this)) showPointer(p.getInt("dotColor", 0), p.getInt("dotSize", 96))
        } catch (e: Exception) { stopAll() }
    }

    private fun showPointer(colorIdx: Int, dpSize: Int) {
        val size = (dpSize * resources.displayMetrics.density).toInt()
        val color = intArrayOf(0xFFFF1744.toInt(), 0xFFFFEA00.toInt(), 0xFF00E676.toInt())[colorIdx.coerceIn(0, 2)]
        val v = PointerView(this, size, color)
        val lp = overlay(size, size, true).apply { x = 200; y = 600 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) moved = true
                    lp.x = sx + dx; lp.y = sy + dy
                    wm.updateViewLayout(v, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) v.pulse()
            }
            true
        }
        wm.addView(v, lp)
        pointer = v
    }

    private fun togglePause() {
        try {
            if (paused) recorder?.resume() else recorder?.pause()
            paused = !paused
            getSystemService(NotificationManager::class.java).notify(2, notif())
        } catch (_: Exception) {}
    }

    private fun stopAll() {
        if (!active && recorder == null && countView == null) { stopSelf(); return }
        active = false
        h.removeCallbacksAndMessages(null)
        var ok = true
        try { recorder?.stop() } catch (_: Exception) { ok = false }
        if (ok) Thread { try { Thread.sleep(1500) } catch (_: Exception) {}; Util.syncAll(applicationContext) }.start()
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        vd?.release(); vd = null
        try { projection?.stop() } catch (_: Exception) {}
        projection = null
        pointer?.let { try { wm.removeView(it) } catch (_: Exception) {} }; pointer = null
        countView?.let { try { wm.removeView(it) } catch (_: Exception) {} }; countView = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { if (active) stopAll(); super.onDestroy() }
}
