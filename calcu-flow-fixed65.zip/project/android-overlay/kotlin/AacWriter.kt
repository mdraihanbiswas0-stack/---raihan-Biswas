package com.earflow.app

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer

// রিয়েল-টাইমে PCM -> AAC (.m4a)। WAV এর তুলনায় ফাইল প্রায় ১০ গুণ ছোট।
class AacWriter(path: String, private val rate: Int, bitrate: Int) {
    private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    private val muxer = MediaMuxer(path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var started = false
    private var samples = 0L

    val durationMs: Long get() = samples * 1000L / rate

    init {
        val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1)
        f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 32768)
        codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    fun write(pcm: ByteArray, len: Int) {
        var off = 0
        while (off < len) {
            val idx = codec.dequeueInputBuffer(10_000)
            if (idx >= 0) {
                val buf = codec.getInputBuffer(idx)!!
                buf.clear()
                val n = minOf(buf.remaining(), len - off) / 2 * 2
                if (n <= 0) { codec.queueInputBuffer(idx, 0, 0, 0, 0); break }
                buf.put(pcm, off, n)
                codec.queueInputBuffer(idx, 0, n, samples * 1_000_000L / rate, 0)
                samples += n / 2
                off += n
            }
            drain(false)
        }
    }

    fun finish() {
        try {
            var sent = false
            var tries = 0
            while (!sent && tries++ < 200) {
                val idx = codec.dequeueInputBuffer(10_000)
                if (idx >= 0) {
                    codec.queueInputBuffer(idx, 0, 0, samples * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    sent = true
                }
                drain(false)
            }
            drain(true)
        } catch (_: Exception) {}
        try { codec.stop() } catch (_: Exception) {}
        try { codec.release() } catch (_: Exception) {}
        try { if (started) muxer.stop() } catch (_: Exception) {}
        try { muxer.release() } catch (_: Exception) {}
    }

    private fun drain(untilEos: Boolean) {
        var tries = 0
        while (true) {
            val i = codec.dequeueOutputBuffer(info, if (untilEos) 10_000L else 0L)
            if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!untilEos || ++tries > 300) return
            } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                track = muxer.addTrack(codec.outputFormat)
                muxer.start()
                started = true
            } else if (i >= 0) {
                val out = codec.getOutputBuffer(i)!!
                if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                if (info.size > 0 && started) {
                    out.position(info.offset)
                    out.limit(info.offset + info.size)
                    muxer.writeSampleData(track, out, info)
                }
                codec.releaseOutputBuffer(i, false)
                if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
            }
        }
    }
}
