package com.earflow.app

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.util.Locale

data class CallInfo(val name: String, val number: String, val incoming: Boolean)

object Util {
    fun size(b: Long): String = when {
        b >= 1_000_000_000L -> String.format(Locale.US, "%.1f GB", b / 1e9)
        b >= 1_000_000L -> String.format(Locale.US, "%.1f MB", b / 1e6)
        else -> "${b / 1000} KB"
    }

    fun dur(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    fun durationOf(f: File): Long = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        r.release(); d
    } catch (e: Exception) { 0L }

    fun thumb(f: File): Bitmap? = try {
        val r = MediaMetadataRetriever()
        r.setDataSource(f.absolutePath)
        val b = r.getFrameAtTime(0)
        r.release()
        if (b == null) null
        else Bitmap.createScaledBitmap(b, 160, (160f * b.height / b.width).toInt().coerceAtLeast(1), true)
    } catch (e: Exception) { null }

    // ফাইলের নাম: নাম_নম্বর_IN/OUT_তারিখ_সময়
    fun parseCall(f: File): CallInfo? {
        val p = f.nameWithoutExtension.split("_")
        if (p.size < 5) return null
        val dir = p[p.size - 3]
        if (dir != "IN" && dir != "OUT") return null
        return CallInfo(p.subList(0, p.size - 4).joinToString(" "), p[p.size - 4], dir == "IN")
    }

    fun share(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "com.earflow.app.fp", f)
        val mime = when (f.extension) { "mp4" -> "video/mp4"; "m4a" -> "audio/mp4"; else -> "audio/x-wav" }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "শেয়ার করুন"))
    }

    private fun sp(ctx: Context) = ctx.getSharedPreferences("ef", Context.MODE_PRIVATE)
    private fun relPath(f: File) = if (f.extension == "mp4") "Movies/EarFlow/" else "Music/EarFlow/"

    // সব রেকর্ডিং (কল + ভিডিও) ফোনের স্টোরেজে (Music/EarFlow, Movies/EarFlow) কপি — ফাইল-ম্যানেজার/গ্যালারি থেকে দেখা যায়।
    // একবার কপি হলে আবার হয় না; অ্যাপ থেকে মুছলে ওই কপিও মোছে।
    @Synchronized
    fun syncAll(ctx: Context) {
        try {
            val base = ctx.getExternalFilesDir(null) ?: return
            val done = HashSet<String>(sp(ctx).getStringSet("exported", emptySet()) ?: emptySet())
            var changed = false
            for (d in listOf("calls", "videos")) {
                File(base, d).listFiles()?.filter { it.isFile && it.length() > 0 && (it.extension == "mp4" || it.extension == "m4a" || it.extension == "wav") }?.forEach { f ->
                    val key = d + "/" + f.name
                    if (!done.contains(key)) {
                        // চলমান রেকর্ডিং (এখনো লেখা হচ্ছে) বাদ — অন্তত ৫ সেকেন্ড আগে শেষ-বদল হওয়া ফাইলই
                        if (System.currentTimeMillis() - f.lastModified() > 5000 && export(ctx, f)) { done.add(key); changed = true }
                    }
                }
            }
            if (changed) sp(ctx).edit().putStringSet("exported", done).apply()
        } catch (_: Exception) {}
    }

    // অ্যাপ থেকে মুছলে ফোনের স্টোরেজের কপিও মোছা
    fun deleteShared(ctx: Context, f: File) {
        try {
            val video = f.extension == "mp4"
            val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            ctx.contentResolver.delete(base,
                MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                arrayOf(f.name, relPath(f)))
            val done = HashSet<String>(sp(ctx).getStringSet("exported", emptySet()) ?: emptySet())
            done.remove((if (video) "videos/" else "calls/") + f.name)
            sp(ctx).edit().putStringSet("exported", done).apply()
        } catch (_: Exception) {}
    }

    // ভিডিও -> Movies/EarFlow, কল অডিও -> Music/EarFlow
    fun export(ctx: Context, f: File): Boolean {
        val video = f.extension == "mp4"
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else if (f.extension == "m4a") "audio/mp4" else "audio/x-wav")
            put(MediaStore.MediaColumns.RELATIVE_PATH, relPath(f))
        }
        val base = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        return try {
            val uri = ctx.contentResolver.insert(base, cv) ?: return false
            ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
            true
        } catch (e: Exception) { false }
    }
}
