package com.omnifinder.app

import android.content.Context

/** টুলের তালিকা, ক্রম, রঙ ও ব্যাকগ্রাউন্ড সংরক্ষণ। */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("omni_prefs", Context.MODE_PRIVATE)

    var userName: String
        get() = sp.getString("name", "") ?: ""
        set(v) = sp.edit().putString("name", v).apply()

    var appBg: Long
        get() = sp.getLong("appBg", 0xFF0B1026)
        set(v) = sp.edit().putLong("appBg", v).apply()

    var barBg: Long
        get() = sp.getLong("barBg", 0xFF151B3D)
        set(v) = sp.edit().putLong("barBg", v).apply()

    var tools: List<Tool>
        get() {
            val s = sp.getString("tools", null) ?: return DefaultTools
            return s.split(",").mapNotNull { n -> Tool.values().find { it.name == n } }
        }
        set(v) = sp.edit().putString("tools", v.joinToString(",") { it.name }).apply()

    var askedPerms: Boolean
        get() = sp.getBoolean("askedPerms", false)
        set(v) = sp.edit().putBoolean("askedPerms", v).apply()

    fun toolColor(t: Tool): Long = sp.getLong("c_${t.name}", t.defColor)
    fun setToolColor(t: Tool, c: Long) = sp.edit().putLong("c_${t.name}", c).apply()
}
