package com.omnifinder.app

import android.content.Intent
import android.os.Bundle
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

class BrowserActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val start = intent?.dataString ?: intent?.getStringExtra("url") ?: ""
        setContent { BrowserScreen(start) { finish() } }
    }
}

private val Bar = Color(0xFF151B3D)
private val Gold = Color(0xFFFFE066)

@Composable
fun BrowserScreen(startUrl: String, onExit: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    val store = remember { BrowserStore(ctx) }
    val tabs = remember { mutableStateListOf<Tab>() }
    var cur by remember { mutableIntStateOf(0) }
    var showTabs by remember { mutableStateOf(false) }
    var showLists by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var findOpen by remember { mutableStateOf(false) }
    var findQ by remember { mutableStateOf("") }
    var ver by remember { mutableIntStateOf(0) }

    fun newTab(url: String = "", incognito: Boolean = false) {
        val t = Tab(ctx, store, incognito) { u -> newTab(u, incognito) }
        tabs.add(t); cur = tabs.lastIndex
        if (url.isNotBlank()) t.go(url)
    }
    fun closeTab(i: Int) {
        tabs.removeAt(i).destroy()
        if (tabs.isEmpty()) onExit() else cur = cur.coerceIn(0, tabs.lastIndex)
    }
    LaunchedEffect(Unit) { if (tabs.isEmpty()) newTab(startUrl) }
    DisposableEffect(Unit) { onDispose { tabs.forEach { it.destroy() }; tabs.clear() } }

    val tab = tabs.getOrNull(cur)
    if (tab == null) { Box(Modifier.fillMaxSize().background(Color(0xFF0B1026))); return }

    BackHandler {
        when {
            findOpen -> { findOpen = false; tab.clearFind() }
            !tab.isHome && tab.canBack -> tab.web.goBack()
            !tab.isHome && tabs.size == 1 -> { tab.web.loadUrl("about:blank"); tab.url = "" }
            tabs.size > 1 -> closeTab(cur)
            else -> onExit()
        }
    }

    var addr by remember(tab, tab.url) { mutableStateOf(tab.url) }
    var focused by remember { mutableStateOf(false) }
    val bookmarked = remember(tab.url, ver) { store.isBookmarked(tab.url) }
    val barColor = if (tab.incognito) Color(0xFF2B1B4D) else Bar

    Column(Modifier.fillMaxSize().background(Color(0xFF0B1026)).statusBarsPadding().navigationBarsPadding().imePadding()) {
        // ওমনিবক্স
        Row(Modifier.fillMaxWidth().background(barColor).padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onExit) { Icon(Icons.Filled.Close, "বন্ধ", tint = Color.White) }
            Row(Modifier.weight(1f).background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(24.dp)).padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (tab.incognito) Icon(Icons.Filled.VisibilityOff, null, tint = Gold, modifier = Modifier.size(18.dp).padding(end = 4.dp))
                Box(Modifier.weight(1f)) {
                    if (addr.isEmpty()) Text("সার্চ করুন বা ঠিকানা লিখুন", color = Color.White.copy(alpha = 0.5f), fontSize = 14.sp)
                    BasicTextField(addr, { addr = it }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(Color.White),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                        keyboardActions = KeyboardActions(onGo = { tab.go(addr); focused = false }),
                        modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused })
                }
                if (!tab.isHome) Icon(if (bookmarked) Icons.Filled.Star else Icons.Filled.StarBorder, "বুকমার্ক", tint = Gold,
                    modifier = Modifier.size(22.dp).clickable { store.toggleBookmark(Page(tab.title, tab.url)); ver++ })
            }
            IconButton({ if (tab.progress in 1..99) tab.web.stopLoading() else tab.web.reload() }, enabled = !tab.isHome) {
                Icon(if (tab.progress in 1..99) Icons.Filled.Close else Icons.Filled.Refresh, "রিলোড", tint = Color.White) }
        }
        if (tab.progress in 1..99 && !tab.isHome) LinearProgressIndicator(progress = { tab.progress / 100f }, modifier = Modifier.fillMaxWidth().height(3.dp), color = Gold, trackColor = Color.Transparent)

        // পেজে খুঁজুন
        if (findOpen) Row(Modifier.fillMaxWidth().background(Bar).padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            BasicTextField(findQ, { findQ = it; tab.find(it) }, singleLine = true, textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Color.White), modifier = Modifier.weight(1f).background(Color.White.copy(alpha = 0.12f), RoundedCornerShape(10.dp)).padding(10.dp))
            Text("${tab.findIndex}/${tab.findTotal}", color = Color.White, modifier = Modifier.padding(horizontal = 8.dp))
            IconButton({ tab.findNext(false) }) { Icon(Icons.Filled.KeyboardArrowUp, null, tint = Color.White) }
            IconButton({ tab.findNext(true) }) { Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color.White) }
            IconButton({ findOpen = false; tab.clearFind() }) { Icon(Icons.Filled.Close, null, tint = Color.White) }
        }

        // কনটেন্ট: সাজেশন / স্টার্ট পেজ / ওয়েব পেজ
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val q = addr.trim()
            if (focused && q.isNotEmpty() && q != tab.url) {
                val all = remember(q) { (store.bookmarks() + store.history()).distinctBy { it.url }
                    .filter { it.title.contains(q, true) || it.url.contains(q, true) }.take(8) }
                LazyColumn(Modifier.fillMaxSize().background(Color(0xFF12172F))) {
                    item { SuggestRow(Glyph.SEARCH, "খুঁজুন / যান: $q", "") { tab.go(q); focused = false } }
                    items(all) { p -> SuggestRow(Glyph.HISTORY, p.title, p.url) { tab.go(p.url); focused = false } }
                }
            } else if (tab.isHome) StartPage(store.bookmarks(), { tab.go(it) }, ver)
            else AndroidView({ FrameLayout(it) }, Modifier.fillMaxSize()) { fl ->
                if (fl.childCount == 0 || fl.getChildAt(0) !== tab.web) {
                    fl.removeAllViews(); (tab.web.parent as? ViewGroup)?.removeView(tab.web)
                    fl.addView(tab.web, FrameLayout.LayoutParams(-1, -1))
                }
            }
        }

        // নিচের বার
        Row(Modifier.fillMaxWidth().background(barColor).padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            IconButton({ tab.web.goBack() }, enabled = tab.canBack && !tab.isHome) { Icon(Icons.Filled.ArrowBack, "পেছনে", tint = Color.White.copy(alpha = if (tab.canBack) 1f else 0.3f)) }
            IconButton({ tab.web.goForward() }, enabled = tab.canForward && !tab.isHome) { Icon(Icons.Filled.ArrowForward, "সামনে", tint = Color.White.copy(alpha = if (tab.canForward) 1f else 0.3f)) }
            IconButton({ newTab() }) { Icon(Icons.Filled.Add, "নতুন ট্যাব", tint = Color.White) }
            Box(Modifier.size(28.dp).background(Color.Transparent, RoundedCornerShape(6.dp)).clickable { showTabs = true }
                .border6(), contentAlignment = Alignment.Center) { Text("${tabs.size}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "মেনু", tint = Color.White) }
                DropdownMenu(menu, { menu = false }) {
                    fun item(t: String, f: () -> Unit) = DropdownMenuItem({ Text(t) }, { menu = false; f() })
                    item("নতুন ইনকগনিটো ট্যাব") { newTab(incognito = true) }
                    item("বুকমার্ক ও ইতিহাস") { showLists = true }
                    item("পেজে খুঁজুন") { if (!tab.isHome) findOpen = true }
                    item(if (tab.desktop) "ডেস্কটপ সাইট" else "ডেস্কটপ সাইট") { tab.setDesktop(!tab.desktop) }
                    item(if (store.darkWeb) "ডার্ক মোড" else "ডার্ক মোড") { store.darkWeb = !store.darkWeb; tabs.forEach { it.applyDark() } }
                    item(if (store.adBlock) "বিজ্ঞাপন ব্লক" else "বিজ্ঞাপন ব্লক") { store.adBlock = !store.adBlock }
                    item("লেখা বড় (${store.textZoom}%)") { store.textZoom = if (store.textZoom >= 160) 80 else store.textZoom + 20; tabs.forEach { it.web.settings.textZoom = store.textZoom } }
                    item("শেয়ার") { if (!tab.isHome) ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, tab.url), "শেয়ার")) }
                    item("অন্য ব্রাউজারে খুলুন") { if (!tab.isHome) runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(tab.url)).setPackage(null).addCategory(Intent.CATEGORY_BROWSABLE)) } }
                    item("ইতিহাস মুছুন") { store.clearHistory(); android.webkit.CookieManager.getInstance().removeAllCookies(null); tab.web.clearCache(true); ver++ }
                }
            }
        }
    }

    if (showTabs) Dialog({ showTabs = false }, DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF12172F)) {
            Column(Modifier.padding(16.dp).statusBarsPadding()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("ট্যাব (${tabs.size})", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton({ newTab(); showTabs = false }) { Text("+ নতুন") }
                    TextButton({ newTab(incognito = true); showTabs = false }) { Text("+ ইনকগনিটো") }
                    IconButton({ showTabs = false }) { Icon(Icons.Filled.Close, null, tint = Color.White) }
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(tabs.size) { i ->
                        val t = tabs[i]
                        Row(Modifier.fillMaxWidth().background(if (i == cur) Color(0xFF26306B) else Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp))
                            .clickable { cur = i; showTabs = false }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text((if (t.incognito) "ইনকগনিটো • " else "") + t.title, color = Color.White, maxLines = 1)
                                Text(t.url.ifBlank { "স্টার্ট পেজ" }, color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, maxLines = 1)
                            }
                            IconButton({ closeTab(i); if (tabs.isEmpty()) showTabs = false }) { Icon(Icons.Filled.Close, null, tint = Color.White) }
                        }
                    }
                }
            }
        }
    }

    if (showLists) ListsDialog(store, ver, { ver++ }, { tab.go(it); showLists = false }) { showLists = false }
}

private fun Modifier.border6() = this.drawBehind {
    drawRoundRect(Color.White, cornerRadius = CornerRadius(12f), style = Stroke(3f))
}

@Composable
private fun SuggestRow(icon: Glyph, title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.padding(end = 12.dp)) { ToolGlyph(icon, 20.dp, Color(0xFFFFE066)) }
        Column { Text(title, color = Color.White, maxLines = 1); if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1) }
    }
}

@Composable
private fun StartPage(bm: List<Page>, open: (String) -> Unit, @Suppress("UNUSED_PARAMETER") ver: Int) {
    val quick = listOf("Wikipedia" to "https://bn.wikipedia.org", "OpenStreetMap" to "https://www.openstreetmap.org", "Quran.com" to "https://quran.com",
        "GitHub" to "https://github.com", "Archive" to "https://archive.org")
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(24.dp))
        Firefly(96.dp)
        Text("ওমনি-ফাইন্ডার", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Chromium ইঞ্জিনে চলা ব্রাউজার", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
        Spacer(Modifier.height(24.dp))
        LazyColumn(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(bm.map { it.title.ifBlank { it.url } to it.url } + quick) { (t, u) ->
                Text(" $t", color = Color.White, maxLines = 1, modifier = Modifier.fillMaxWidth().background(Color.White.copy(alpha = 0.07f), RoundedCornerShape(14.dp)).clickable { open(u) }.padding(14.dp))
            }
        }
    }
}

@Composable
private fun ListsDialog(store: BrowserStore, ver: Int, refresh: () -> Unit, open: (String) -> Unit, close: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val list = remember(tab, ver) { if (tab == 0) store.bookmarks() else store.history() }
    Dialog(close, DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF12172F)) {
            Column(Modifier.statusBarsPadding().padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton({ tab = 0 }) { Text(if (tab == 0) "বুকমার্ক" else "বুকমার্ক") }
                    TextButton({ tab = 1 }) { Text(if (tab == 1) "ইতিহাস" else "ইতিহাস") }
                    Spacer(Modifier.weight(1f))
                    if (tab == 1) TextButton({ store.clearHistory(); refresh() }) { Text("সব মুছুন") }
                    IconButton(close) { Icon(Icons.Filled.Close, null, tint = Color.White) }
                }
                LazyColumn {
                    items(list) { p ->
                        Row(Modifier.fillMaxWidth().clickable { open(p.url) }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(p.title.ifBlank { p.url }, color = Color.White, maxLines = 1); Text(p.url, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, maxLines = 1) }
                            if (tab == 0) IconButton({ store.removeBookmark(p.url); refresh() }) { Icon(Icons.Filled.Delete, null, tint = Color(0xFFFF6B6B)) }
                        }
                    }
                }
            }
        }
    }
}
