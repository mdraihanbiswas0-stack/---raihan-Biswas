package com.omnifinder.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Environment
import android.webkit.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import java.io.ByteArrayInputStream

private const val DESKTOP_UA =
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

private val AdHosts = listOf(
    "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.", "adnxs.com",
    "taboola.com", "outbrain.com", "pubmatic.com", "rubiconproject.com", "criteo.com", "scorecardresearch.com",
    "adsterra.com", "popads.net", "propellerads.com", "mgid.com", "ads.yahoo.com", "moatads.com"
)

/** একটি ব্রাউজার ট্যাব = একটি Chromium WebView। */
@SuppressLint("SetJavaScriptEnabled")
class Tab(val ctx: Context, val store: BrowserStore, val incognito: Boolean, val onOpenNew: (String) -> Unit) {
    val web = WebView(ctx)
    var title by mutableStateOf("নতুন ট্যাব")
    var url by mutableStateOf("")
    var progress by mutableIntStateOf(0)
    var canBack by mutableStateOf(false)
    var canForward by mutableStateOf(false)
    var desktop by mutableStateOf(false)
    var findTotal by mutableIntStateOf(0)
    var findIndex by mutableIntStateOf(0)
    val isHome get() = url.isBlank()
    private val defaultUA: String

    init {
        val s = web.settings
        defaultUA = s.userAgentString
        s.javaScriptEnabled = store.javaScript
        s.domStorageEnabled = !incognito
        s.databaseEnabled = !incognito
        s.cacheMode = if (incognito) WebSettings.LOAD_NO_CACHE else WebSettings.LOAD_DEFAULT
        s.setSupportZoom(true); s.builtInZoomControls = true; s.displayZoomControls = false
        s.loadWithOverviewMode = true; s.useWideViewPort = true
        s.mediaPlaybackRequiresUserGesture = true
        s.setSupportMultipleWindows(true); s.javaScriptCanOpenWindowsAutomatically = true
        s.textZoom = store.textZoom
        s.allowFileAccess = false; s.allowContentAccess = false
        s.safeBrowsingEnabled = true
        s.saveFormData = !incognito
        applyDark()
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, !incognito)

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) { url = u; progress = 5; nav() }
            override fun onPageFinished(v: WebView, u: String) {
                url = u; title = v.title?.takeIf { it.isNotBlank() } ?: u; progress = 100; nav()
                if (!incognito) store.addHistory(Page(title, u))
            }
            override fun doUpdateVisitedHistory(v: WebView, u: String, r: Boolean) { nav() }
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme == "http" || u.scheme == "https" || u.scheme == "about") return false
                runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                return true
            }
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                if (store.adBlock && AdHosts.any { r.url.host?.contains(it) == true })
                    return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                return null
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) { progress = p }
            override fun onReceivedTitle(v: WebView, t: String?) { if (!t.isNullOrBlank()) title = t }
            override fun onCreateWindow(v: WebView, d: Boolean, g: Boolean, m: android.os.Message): Boolean {
                // নতুন উইন্ডো নতুন ট্যাবে
                val t = WebView(ctx); t.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(w: WebView, r: WebResourceRequest): Boolean {
                        onOpenNew(r.url.toString()); w.destroy(); return true }
                }
                (m.obj as WebView.WebViewTransport).webView = t; m.sendToTarget(); return true
            }
        }
        web.setDownloadListener { u, ua, cd, mime, _ ->
            runCatching {
                val name = URLUtil.guessFileName(u, cd, mime)
                val req = DownloadManager.Request(Uri.parse(u))
                    .setMimeType(mime).addRequestHeader("User-Agent", ua)
                    .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(u) ?: "")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (ctx.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                android.widget.Toast.makeText(ctx, "ডাউনলোড শুরু: $name", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        web.setFindListener { idx, total, _ -> findIndex = if (total == 0) 0 else idx + 1; findTotal = total }
    }

    private fun nav() { canBack = web.canGoBack(); canForward = web.canGoForward() }

    fun applyDark() {
        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING))
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(web.settings, store.darkWeb)
    }

    fun setDesktop(on: Boolean) {
        desktop = on
        web.settings.userAgentString = if (on) DESKTOP_UA else defaultUA
        web.reload()
    }

    /** সার্চ শব্দ বা ঠিকানা — দুটোই চলে (ওমনিবক্স)। */
    fun go(input: String) {
        val t = input.trim(); if (t.isEmpty()) return
        val isUrl = t.startsWith("http://") || t.startsWith("https://") ||
            (!t.contains(' ') && t.contains('.') && !t.endsWith("."))
        val target = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            isUrl -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        url = target; web.loadUrl(target)
    }

    fun find(q: String) { if (q.isEmpty()) web.clearMatches() else web.findAllAsync(q) }
    fun findNext(fwd: Boolean) = web.findNext(fwd)
    fun clearFind() { web.clearMatches(); findTotal = 0; findIndex = 0 }

    fun destroy() {
        if (incognito) { web.clearHistory(); web.clearCache(true); web.clearFormData() }
        (web.parent as? android.view.ViewGroup)?.removeView(web); web.destroy()
    }
}
