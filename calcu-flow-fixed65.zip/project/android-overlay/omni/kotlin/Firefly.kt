package com.omnifinder.app

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** জোনাকি: পেছনে জ্বলা আলো, রঙিন দুই ডানা, ডানা ঝাপটানো ও মাঝেমধ্যে ঘুরে নাচ। */
@Composable
fun Firefly(size: Dp = 44.dp, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "ff")
    val flap by t.animateFloat(0f, 1f, infiniteRepeatable(tween(180, easing = LinearEasing), RepeatMode.Reverse), label = "flap")
    val glow by t.animateFloat(0.45f, 1f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    val dance by t.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "dance")

    Canvas(modifier.size(size)) {
        val w = this.size.width
        // শেষ ২৫% সময়ে ছোট বৃত্তাকার নাচ, বাকি সময় হালকা ভাসা
        val danceP = ((dance - 0.75f) / 0.25f).coerceIn(0f, 1f)
        val ang = danceP * 2 * PI.toFloat()
        val dx = (if (danceP > 0f) sin(ang) * 0.12f else 0f) * w + sin(dance * 12f) * 0.01f * w
        val dy = (if (danceP > 0f) (1 - cos(ang)) * 0.08f else 0f) * w + cos(dance * 9f) * 0.015f * w
        val tilt = if (danceP > 0f) sin(ang) * 18f else 0f
        val c = Offset(w / 2 + dx, w / 2 + dy)

        rotate(tilt, c) {
            // পেছনের আলো
            val glowC = Offset(c.x, c.y + w * 0.17f)
            drawCircle(Brush.radialGradient(
                listOf(Color(0xFFFFF176).copy(alpha = glow), Color(0xFFFFC107).copy(alpha = glow * 0.45f), Color.Transparent),
                glowC, w * 0.55f), w * 0.55f, glowC)

            // ডানা (রঙিন), ঝাপটানোর কোণ flap দিয়ে
            val wingAng = 10f + flap * 38f
            val wingW = w * 0.34f; val wingH = w * 0.2f
            fun wing(sign: Float, colors: List<Color>) {
                val pivot = Offset(c.x, c.y - w * 0.04f)
                rotate(-sign * wingAng - sign * 20f, pivot) {
                    val tl = Offset(pivot.x + if (sign > 0) 0f else -wingW, pivot.y - wingH / 2)
                    drawOval(Brush.linearGradient(colors, tl, tl + Offset(wingW, wingH)), tl, Size(wingW, wingH), alpha = 0.85f)
                }
            }
            wing(1f, listOf(Color(0xFFFF4D8D), Color(0xFFFFB347)))
            wing(-1f, listOf(Color(0xFF00E5FF), Color(0xFF7C4DFF)))

            // শরীর
            drawOval(Color(0xFF3B2A1A), Offset(c.x - w * 0.07f, c.y - w * 0.14f), Size(w * 0.14f, w * 0.3f))
            // জ্বলন্ত লেজ
            drawOval(Brush.radialGradient(listOf(Color.White, Color(0xFFFFEB3B), Color(0xFFFFA000)), Offset(c.x, c.y + w * 0.12f), w * 0.1f),
                Offset(c.x - w * 0.07f, c.y + w * 0.04f), Size(w * 0.14f, w * 0.14f))
            // মাথা ও চোখ
            drawCircle(Color(0xFF2A1D12), w * 0.06f, Offset(c.x, c.y - w * 0.17f))
            drawCircle(Color.White, w * 0.015f, Offset(c.x - w * 0.02f, c.y - w * 0.18f))
            drawCircle(Color.White, w * 0.015f, Offset(c.x + w * 0.02f, c.y - w * 0.18f))
            // শুঁড়
            drawLine(Color(0xFF3B2A1A), Offset(c.x - w * 0.02f, c.y - w * 0.22f), Offset(c.x - w * 0.07f, c.y - w * 0.32f), 2f)
            drawLine(Color(0xFF3B2A1A), Offset(c.x + w * 0.02f, c.y - w * 0.22f), Offset(c.x + w * 0.07f, c.y - w * 0.32f), 2f)
        }
    }
}
