package __APP_ID__;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    /** হোম-স্ক্রিন উইজেটে ট্যাপ করলে যে প্যাডে যেতে হবে (ওয়েব অংশ নিয়ে নিলে ফাঁকা হয়ে যায়) */
    public static volatile String pendingPad = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // নিজস্ব নেটিভ প্লাগইন (ভয়েস, বায়োমেট্রিক, ফাইল-সেভ, অটোফিল, ক্লিপবোর্ড…)
        registerPlugin(JonakiNativePlugin.class);
        super.onCreate(savedInstanceState);
        grabPad(getIntent());
        try {
            WebView wv = getBridge().getWebView();
            WebSettings s = wv.getSettings();
            // রিমাইন্ডারের শব্দ/ভয়েস গেস্টার ছাড়াই বাজতে পারবে
            s.setMediaPlaybackRequiresUserGesture(false);
            // ফোনের ফন্ট-সাইজ সেটিং অ্যাপের ডিজাইন ভাঙবে না
            s.setTextZoom(100);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        } catch (Throwable ignored) {
        }
    }

    /** অ্যাপ আগে থেকেই খোলা থাকলে উইজেট-ট্যাপ এখানে আসে */
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (grabPad(intent)) pushPad();
    }

    private static boolean grabPad(Intent i) {
        try {
            if (i == null) return false;
            String p = i.getStringExtra(PadWidgets.EXTRA_PAD);
            if (PadWidgets.isPad(p)) {
                pendingPad = p;
                i.removeExtra(PadWidgets.EXTRA_PAD);
                return true;
            }
        } catch (Throwable ignored) {
        }
        return false;
    }

    /** চালু থাকা পাতাকে সরাসরি জানানো; ওয়েব অংশ কাজ শেষে নিজেই pendingPad মুছে দেয় (getLaunchPad) */
    private void pushPad() {
        try {
            final String p = pendingPad;
            if (p == null) return;
            final WebView wv = getBridge().getWebView();
            wv.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        wv.evaluateJavascript("window.__openPad&&window.__openPad('" + p + "')", null);
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }
}
