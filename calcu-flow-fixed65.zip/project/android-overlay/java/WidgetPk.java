package __APP_ID__;

/** "pk" প্যাডের উইজেট */
public class WidgetPk extends PadWidgetBase {
    @Override
    protected String pad() {
        return "pk";
    }
}
