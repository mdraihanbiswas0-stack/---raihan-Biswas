package __APP_ID__;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.assist.AssistStructure;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.service.autofill.Dataset;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillValue;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.util.List;

/**
 * অটোফিলের আগে স্ক্রিন-লক দিয়ে যাচাই; একাধিক মিল থাকলে বেছে নেওয়ার তালিকা দেখায়।
 */
public class AutofillAuthActivity extends Activity {

    private static final int RC_LOCK = 71;

    private String entryId;
    private AutofillId userId;
    private AutofillId passId;
    private java.util.ArrayList<AutofillId> passes;
    private boolean suggest;
    private String sugPkg = "";
    private String sugWeb = "";

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        entryId = in.getStringExtra("entry");
        suggest = in.getBooleanExtra("suggest", false);
        if (suggest) {
            try {
                passes = in.getParcelableArrayListExtra("passes");
                sugPkg = in.getStringExtra("pkg") == null ? "" : in.getStringExtra("pkg");
                sugWeb = in.getStringExtra("web") == null ? "" : in.getStringExtra("web");
            } catch (Throwable t) {
                passes = null;
            }
            if (passes == null || passes.isEmpty()) {
                cancel();
                return;
            }
            showSuggest(genPassword());
            return;
        }
        try {
            userId = in.getParcelableExtra("user");
            passId = in.getParcelableExtra("pass");
        } catch (Throwable t) {
            userId = null;
            passId = null;
        }
        if (userId == null && passId == null) {
            cancel();
            return;
        }
        try {
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (km != null && km.isDeviceSecure()) {
                Intent li = km.createConfirmDeviceCredentialIntent(
                        "কী-ফ্লো অটোফিল", "লগইন তথ্য বসাতে স্ক্রিন-লক দিয়ে যাচাই করুন");
                if (li != null) {
                    startActivityForResult(li, RC_LOCK);
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
        proceed();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_LOCK) {
            if (res == RESULT_OK) proceed();
            else cancel();
        }
    }

    private void proceed() {
        final List<AutofillStore.Entry> all = AutofillStore.load(this);
        if (all.isEmpty()) {
            Toast.makeText(this, "কী-ফ্লোতে সংরক্ষিত লগইন নেই", Toast.LENGTH_SHORT).show();
            cancel();
            return;
        }
        if (entryId != null) {
            for (AutofillStore.Entry e : all) {
                if (entryId.equals(e.id)) {
                    done(e);
                    return;
                }
            }
            cancel();
            return;
        }
        String[] labels = new String[all.size()];
        for (int i = 0; i < labels.length; i++) {
            AutofillStore.Entry e = all.get(i);
            String t = e.title.length() > 0 ? e.title : AutofillStore.hostOf(e.url);
            labels[i] = e.user.length() > 0 ? t + "\n" + e.user : t;
        }
        new AlertDialog.Builder(this)
                .setTitle("কী-ফ্লো — লগইন বাছুন")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        done(all.get(which));
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface d) {
                        cancel();
                    }
                })
                .show();
    }

    @SuppressWarnings("deprecation")
    private void done(AutofillStore.Entry e) {
        try {
            RemoteViews rv = new RemoteViews(getPackageName(), R.layout.autofill_item);
            rv.setTextViewText(R.id.af_title, e.title.length() > 0 ? e.title : AutofillStore.hostOf(e.url));
            rv.setTextViewText(R.id.af_sub, e.user);
            Dataset.Builder db = new Dataset.Builder(rv);
            if (userId != null) db.setValue(userId, AutofillValue.forText(e.user));
            if (passId != null) db.setValue(passId, AutofillValue.forText(e.pass));
            Intent reply = new Intent();
            reply.putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, db.build());
            setResult(RESULT_OK, reply);
        } catch (Throwable t) {
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    /* ---------- শক্তিশালী পাসওয়ার্ড সাজেশন ---------- */

    private static String genPassword() {
        final String U = "ABCDEFGHJKLMNPQRSTUVWXYZ", L = "abcdefghijkmnpqrstuvwxyz", N = "23456789", S = "!@#$%^&*-_=+?";
        java.security.SecureRandom r = new java.security.SecureRandom();
        String all = U + L + N + S;
        char[] c = new char[20];
        c[0] = U.charAt(r.nextInt(U.length()));
        c[1] = L.charAt(r.nextInt(L.length()));
        c[2] = N.charAt(r.nextInt(N.length()));
        c[3] = S.charAt(r.nextInt(S.length()));
        for (int i = 4; i < c.length; i++) c[i] = all.charAt(r.nextInt(all.length()));
        for (int i = c.length - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            char t = c[i];
            c[i] = c[j];
            c[j] = t;
        }
        return new String(c);
    }

    private void showSuggest(final String pw) {
        final android.widget.TextView tv = new android.widget.TextView(this);
        tv.setText(pw);
        tv.setTextSize(20);
        tv.setTypeface(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD);
        tv.setGravity(android.view.Gravity.CENTER);
        tv.setTextIsSelectable(true);
        tv.setPadding(24, 36, 24, 12);
        AlertDialog d = new AlertDialog.Builder(this)
                .setTitle("✨ কী-ফ্লো: শক্তিশালী পাসওয়ার্ড")
                .setView(tv)
                .setMessage("২০ অক্ষরের এলোমেলো পাসওয়ার্ড। ‘ব্যবহার করুন’ চাপলে ফর্মে বসবে এবং কী-ফ্লো ভল্টে সেভ থাকবে — মনে রাখতে হবে না।")
                .setPositiveButton("ব্যবহার করুন", null)
                .setNeutralButton("অন্যটি", null)
                .setNegativeButton("বাতিল", null)
                .create();
        d.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface x) {
                cancel();
            }
        });
        d.show();
        final String[] cur = {pw};
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                useSuggested(cur[0]);
            }
        });
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                cur[0] = genPassword();
                tv.setText(cur[0]);
            }
        });
        d.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View v) {
                cancel();
            }
        });
    }

    @SuppressWarnings("deprecation")
    private void useSuggested(String pw) {
        try {
            // ব্যবহারকারী ফর্ম জমা দেওয়ার আগেই হারিয়ে না যায় — ড্রাফট হিসেবে সাথে সাথে সেভ (জমা দিলে ইউজারনেম যুক্ত হয়)
            AutofillStore.Entry e = new AutofillStore.Entry();
            boolean web = sugWeb.length() > 0;
            e.url = web ? "https://" + sugWeb : "app://" + sugPkg;
            e.title = web ? AutofillStore.hostOf(e.url) : sugPkg;
            e.pass = pw;
            e.draft = true;
            AutofillStore.upsertPending(this, e);
            RemoteViews rv = new RemoteViews(getPackageName(), R.layout.autofill_item);
            rv.setTextViewText(R.id.af_title, "✨ সাজেস্ট করা পাসওয়ার্ড");
            rv.setTextViewText(R.id.af_sub, "কী-ফ্লোতে সেভ হচ্ছে");
            Dataset.Builder db = new Dataset.Builder(rv);
            for (AutofillId id : passes) db.setValue(id, AutofillValue.forText(pw));
            Intent reply = new Intent();
            reply.putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, db.build());
            setResult(RESULT_OK, reply);
            Toast.makeText(this, "🔐 পাসওয়ার্ড বসেছে ও কী-ফ্লোতে সেভ হয়েছে", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    private void cancel() {
        setResult(RESULT_CANCELED);
        finish();
    }
}
