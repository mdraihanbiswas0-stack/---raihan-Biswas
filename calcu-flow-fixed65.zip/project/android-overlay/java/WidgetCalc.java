package __APP_ID__;

/** "calc" প্যাডের উইজেট */
public class WidgetCalc extends PadWidgetBase {
    @Override
    protected String pad() {
        return "calc";
    }
}
