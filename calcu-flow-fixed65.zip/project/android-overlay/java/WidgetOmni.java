package __APP_ID__;

/** "omni" (ওমনি-ফাইন্ডার) প্যাডের উইজেট — ট্যাপ করলে সরাসরি ওমনি-ফাইন্ডার খোলে */
public class WidgetOmni extends PadWidgetBase {
    @Override
    protected String pad() {
        return "omni";
    }
}
