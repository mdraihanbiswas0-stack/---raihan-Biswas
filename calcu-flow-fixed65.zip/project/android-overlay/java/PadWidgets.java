package __APP_ID__;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.Calendar;
import java.util.Locale;

/**
 * হোম-স্ক্রিন উইজেটের সহায়ক: প্যাডের তালিকা, ট্যাপে সরাসরি প্যাডে যাওয়ার PendingIntent,
 * উইজেটের ছবি বসানো, আর "ঘরে পিন করা" অনুরোধ।
 */
public final class PadWidgets {
    private PadWidgets() {}

    /** অ্যাপের ভেতরের ট্যাব-আইডি (index.html-এর tab('…')) — লম্বা উইজেটের ক্রম এটাই */
    public static final String[] PADS = {"pk", "calc", "biz", "nt", "med", "kf", "cal", "jf", "ear", "omni"};

    public static final String ACTION_OPEN_PAD = "__APP_ID__.OPEN_PAD";
    public static final String EXTRA_PAD = "pad";

    public static boolean isPad(String id) {
        if (id == null) return false;
        for (String p : PADS) if (p.equals(id)) return true;
        return false;
    }

    /** আইডি → উইজেট প্রোভাইডার ক্লাস (পিন করার জন্য); "bar" = লম্বা উইজেট */
    public static Class<?> providerFor(String kind) {
        if ("pk".equals(kind)) return WidgetPk.class;
        if ("calc".equals(kind)) return WidgetCalc.class;
        if ("biz".equals(kind)) return WidgetBiz.class;
        if ("nt".equals(kind)) return WidgetNt.class;
        if ("med".equals(kind)) return WidgetMed.class;
        if ("kf".equals(kind)) return WidgetKf.class;
        if ("cal".equals(kind)) return WidgetCal.class;
        if ("jf".equals(kind)) return WidgetJf.class;
        if ("ear".equals(kind)) return WidgetEar.class;
        if ("omni".equals(kind)) return WidgetOmni.class;
        if ("omni_search".equals(kind)) return com.jonaki.search.OmniFinderWidget.class;
        if ("bar".equals(kind)) return WidgetBar.class;
        return null;
    }

    /** ট্যাপ করলে MainActivity খুলে সেই প্যাডে নিয়ে যাবে */
    public static PendingIntent openPadIntent(Context ctx, String pad) {
        if ("ear".equals(pad)) {
            // ইয়ার-ফ্লো রেকর্ডার সরাসরি খোলে
            Intent e = new Intent(ctx, com.earflow.app.EarActivity.class);
            e.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            return PendingIntent.getActivity(ctx, 7100, e, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        }
        if ("omni".equals(pad)) {
            // ওমনি-ফাইন্ডার সরাসরি খোলে
            Intent o = new Intent(ctx, com.jonaki.search.OmniActivity.class);
            o.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            return PendingIntent.getActivity(ctx, 7101, o, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        }
        Intent i = new Intent(ctx, MainActivity.class);
        i.setAction(ACTION_OPEN_PAD);
        i.putExtra(EXTRA_PAD, pad);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int code = 7000;
        for (int k = 0; k < PADS.length; k++) if (PADS[k].equals(pad)) code = 7000 + k;
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    public static int drawableOf(Context ctx, String pad) {
        return ctx.getResources().getIdentifier("pad_" + pad, "drawable", ctx.getPackageName());
    }

    /** একটি ImageView-তে প্যাডের লোগো (ক্যালেন্ডার হলে আজকের বার-তারিখসহ ছবি) বসানো ও ট্যাপ বাঁধা */
    public static void bindLogo(Context ctx, RemoteViews rv, int viewId, String pad, Calendar now) {
        if ("cal".equals(pad)) {
            Bitmap bm = CalendarLogo.draw(256, now);
            rv.setImageViewBitmap(viewId, bm);
        } else {
            int res = drawableOf(ctx, pad);
            if (res != 0) rv.setImageViewResource(viewId, res);
        }
        rv.setOnClickPendingIntent(viewId, openPadIntent(ctx, pad));
    }

    public static Calendar now() {
        return Calendar.getInstance(Locale.ENGLISH);
    }

    /** লাঞ্চার সমর্থন করলে "হোম স্ক্রিনে যোগ করুন" ডায়ালগ দেখায়। ফেরত: "ok" / "unsupported" / "unknown" / "error" */
    public static String requestPin(Context ctx, String kind) {
        try {
            if (Build.VERSION.SDK_INT < 26) return "unsupported";
            Class<?> cls = providerFor(kind);
            if (cls == null) return "unknown";
            AppWidgetManager m = AppWidgetManager.getInstance(ctx);
            if (m == null || !m.isRequestPinAppWidgetSupported()) return "unsupported";
            ComponentName cn = new ComponentName(ctx, cls);
            return m.requestPinAppWidget(cn, null, null) ? "ok" : "unsupported";
        } catch (Throwable t) {
            return "error";
        }
    }
}
