package __APP_ID__;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.KeyguardManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.os.PersistableBundle;
import android.os.PowerManager;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.util.Base64;
import android.view.WindowManager;
import android.view.autofill.AutofillManager;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * ওয়েব-অ্যাপের জন্য নেটিভ সেতু: ভয়েস-ইনপুট, বায়োমেট্রিক, ফাইল সেভ/শেয়ার, ক্লিপবোর্ড,
 * অটোফিল, স্ক্রিন-অন, সেটিংস-শর্টকাট ও অনুমতির অবস্থা।
 */
@SuppressLint("NewApi")
@CapacitorPlugin(
        name = "JonakiNative",
        permissions = {
                @Permission(alias = "microphone", strings = {Manifest.permission.RECORD_AUDIO})
        }
)
public class JonakiNativePlugin extends Plugin {

    private SpeechRecognizer recognizer;
    private boolean speechPartial = false;
    private final List<Integer> mutedStreams = new ArrayList<>();

    @Override
    public void load() {
        // আগের কোনো ক্র্যাশে আটকে-যাওয়া মিউট ছাড়ানো
        setBeepMuted(false);
    }

    @Override
    protected void handleOnPause() {
        super.handleOnPause();
        destroyRecognizer();
        ttsHalt();
    }

    @Override
    protected void handleOnDestroy() {
        destroyRecognizer();
        ttsShutdown();
        super.handleOnDestroy();
    }

    /* ================= অবস্থা ================= */

    @PluginMethod
    public void getInfo(PluginCall call) {
        JSObject r = new JSObject();
        Context c = getContext();
        r.put("sdk", Build.VERSION.SDK_INT);
        r.put("mic", getPermissionState("microphone") == PermissionState.GRANTED);
        boolean exact = true;
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
                exact = am != null && am.canScheduleExactAlarms();
            }
        } catch (Throwable ignored) {
        }
        r.put("exactAlarm", exact);
        boolean battery = false;
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
                battery = pm != null && pm.isIgnoringBatteryOptimizations(c.getPackageName());
            }
        } catch (Throwable ignored) {
        }
        r.put("batteryIgnored", battery);
        boolean afSupported = false;
        boolean afEnabled = false;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                AutofillManager afm = c.getSystemService(AutofillManager.class);
                if (afm != null) {
                    afSupported = afm.isAutofillSupported();
                    afEnabled = afm.hasEnabledAutofillServices();
                }
            }
        } catch (Throwable ignored) {
        }
        r.put("autofillSupported", afSupported);
        r.put("autofillEnabled", afEnabled);
        boolean secure = false;
        try {
            KeyguardManager km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
            secure = km != null && km.isDeviceSecure();
        } catch (Throwable ignored) {
        }
        r.put("deviceSecure", secure);
        boolean speech = false;
        try {
            speech = SpeechRecognizer.isRecognitionAvailable(c);
        } catch (Throwable ignored) {
        }
        r.put("speechAvailable", speech);
        call.resolve(r);
    }

    /* ================= অনুমতি ================= */

    @PluginMethod
    public void requestMic(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) {
            JSObject r = new JSObject();
            r.put("granted", true);
            call.resolve(r);
            return;
        }
        requestPermissionForAlias("microphone", call, "micCallback");
    }

    @PermissionCallback
    private void micCallback(PluginCall call) {
        JSObject r = new JSObject();
        r.put("granted", getPermissionState("microphone") == PermissionState.GRANTED);
        call.resolve(r);
    }

    @PluginMethod
    public void openSettings(PluginCall call) {
        String type = call.getString("type", "app");
        Context c = getContext();
        String pkg = c.getPackageName();
        Intent i;
        try {
            if ("notification".equals(type) && Build.VERSION.SDK_INT >= 26) {
                i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
            } else if ("exactAlarm".equals(type) && Build.VERSION.SDK_INT >= 31) {
                i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + pkg));
            } else if ("battery".equals(type)) {
                i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg));
            } else if ("autofill".equals(type) && Build.VERSION.SDK_INT >= 26) {
                i = new Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE, Uri.parse("package:" + pkg));
            } else {
                i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
            }
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Throwable t) {
            try {
                Intent d = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
                d.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(d);
            } catch (Throwable ignored) {
            }
        }
        call.resolve();
    }

    /* ================= জোরে-পড়া (Android TextToSpeech) =================
     * WebView-তে speechSynthesis নেই — তাই জোনাকির কণ্ঠ ও নোট-পড়া এই পথে ফোনের নিজস্ব TTS ইঞ্জিনে বাজে। */

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private boolean ttsIniting = false;
    private int ttsSeq = 0;
    private final List<Runnable> ttsWaiters = new ArrayList<>();
    private final Map<String, PluginCall> ttsCalls = new HashMap<>();

    @PluginMethod
    public void ttsSpeak(final PluginCall call) {
        String txt = call.getString("text", "");
        if (txt == null || txt.trim().length() == 0) {
            call.resolve();
            return;
        }
        runOnUi(new Runnable() {
            @Override
            public void run() {
                ttsWhenReady(new Runnable() {
                    @Override
                    public void run() {
                        ttsRun(call);
                    }
                });
            }
        });
    }

    /** ফোনে থাকা সব বাংলা কণ্ঠের তালিকা (দুই জোনাকির জন্য আলাদা কণ্ঠ বাছতে) */
    @PluginMethod
    public void ttsVoices(final PluginCall call) {
        runOnUi(new Runnable() {
            @Override
            public void run() {
                ttsWhenReady(new Runnable() {
                    @Override
                    public void run() {
                        JSArray arr = new JSArray();
                        try {
                            if (ttsReady && tts != null) {
                                Set<Voice> vs = tts.getVoices();
                                if (vs != null) {
                                    for (Voice v : vs) {
                                        Locale l = v.getLocale();
                                        if (l == null || !"bn".equalsIgnoreCase(l.getLanguage())) continue;
                                        JSObject o = new JSObject();
                                        o.put("name", v.getName());
                                        o.put("lang", l.toLanguageTag());
                                        o.put("quality", v.getQuality());
                                        o.put("latency", v.getLatency());
                                        o.put("net", v.isNetworkConnectionRequired());
                                        arr.put(o);
                                    }
                                }
                            }
                        } catch (Throwable ignored) {
                        }
                        JSObject r = new JSObject();
                        r.put("voices", arr);
                        call.resolve(r);
                    }
                });
            }
        });
    }

    @PluginMethod
    public void ttsStop(final PluginCall call) {
        runOnUi(new Runnable() {
            @Override
            public void run() {
                ttsHalt();
                call.resolve();
            }
        });
    }

    private void ttsWhenReady(Runnable then) {
        if (ttsReady && tts != null) {
            then.run();
            return;
        }
        ttsWaiters.add(then);
        if (ttsIniting) return;
        ttsIniting = true;
        try {
            tts = new TextToSpeech(getContext().getApplicationContext(), new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(final int status) {
                    runOnUi(new Runnable() {
                        @Override
                        public void run() {
                            ttsInitDone(status == TextToSpeech.SUCCESS);
                        }
                    });
                }
            });
        } catch (Throwable t) {
            ttsInitDone(false);
        }
    }

    private void ttsInitDone(boolean ok) {
        ttsIniting = false;
        ttsReady = ok && tts != null;
        if (ttsReady) {
            try {
                tts.setOnUtteranceProgressListener(new TtsListener());
            } catch (Throwable ignored) {
            }
        } else if (tts != null) {
            try {
                tts.shutdown();
            } catch (Throwable ignored) {
            }
            tts = null;
        }
        List<Runnable> w = new ArrayList<>(ttsWaiters);
        ttsWaiters.clear();
        for (Runnable r : w) {
            try {
                r.run();
            } catch (Throwable ignored) {
            }
        }
    }

    private Locale ttsLocale(String tag) {
        if (tag == null || tag.length() == 0) return new Locale("bn", "BD");
        String[] p = tag.replace('_', '-').split("-");
        return p.length > 1 ? new Locale(p[0], p[1]) : new Locale(p[0]);
    }

    /** বাংলা কণ্ঠ বাছাই: অনুরোধ করা ভাষা → bn-BD → bn-IN → bn */
    private boolean ttsPickLang(String tag) {
        Locale[] cands = new Locale[]{ttsLocale(tag), new Locale("bn", "BD"), new Locale("bn", "IN"), new Locale("bn")};
        for (Locale l : cands) {
            try {
                int r = tts.setLanguage(l);
                if (r >= TextToSpeech.LANG_AVAILABLE) return true;
            } catch (Throwable ignored) {
            }
        }
        return false;
    }

    private float ttsClamp(Float v, float lo, float hi, float d) {
        float x = v == null ? d : v.floatValue();
        if (Float.isNaN(x)) x = d;
        return Math.max(lo, Math.min(hi, x));
    }

    private void ttsRun(PluginCall call) {
        if (!ttsReady || tts == null) {
            call.reject("tts-init");
            return;
        }
        try {
            String text = call.getString("text", "");
            int max = TextToSpeech.getMaxSpeechInputLength();
            if (text.length() > max) text = text.substring(0, max);
            // নির্দিষ্ট কণ্ঠ চাইলে সেটি; না পেলে ভাষা ধরে বাছাই
            boolean voiceSet = false;
            String vn = call.getString("voice", "");
            if (vn != null && vn.length() > 0) {
                try {
                    Set<Voice> all = tts.getVoices();
                    if (all != null) {
                        for (Voice v : all) {
                            if (vn.equals(v.getName())) {
                                voiceSet = tts.setVoice(v) == TextToSpeech.SUCCESS;
                                break;
                            }
                        }
                    }
                } catch (Throwable ignored) {
                }
            }
            if (!voiceSet && !ttsPickLang(call.getString("lang", "bn-BD"))) {
                call.reject("lang-missing");
                return;
            }
            tts.setPitch(ttsClamp(call.getFloat("pitch", 1f), 0.5f, 2f, 1f));
            tts.setSpeechRate(ttsClamp(call.getFloat("rate", 1f), 0.3f, 2.5f, 1f));
            Bundle params = new Bundle();
            params.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, ttsClamp(call.getFloat("volume", 1f), 0f, 1f, 1f));
            ttsResolveAll(); // QUEUE_FLUSH পুরনো কথা থামিয়ে দেবে — তাদের অপেক্ষা শেষ করি
            String id = "jn" + (++ttsSeq);
            synchronized (ttsCalls) {
                ttsCalls.put(id, call);
            }
            int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
            if (r != TextToSpeech.SUCCESS) {
                synchronized (ttsCalls) {
                    ttsCalls.remove(id);
                }
                call.reject("tts-error");
            }
        } catch (Throwable t) {
            call.reject("tts-error");
        }
    }

    private void ttsResolveAll() {
        List<PluginCall> l;
        synchronized (ttsCalls) {
            l = new ArrayList<>(ttsCalls.values());
            ttsCalls.clear();
        }
        for (PluginCall c : l) {
            try {
                c.resolve();
            } catch (Throwable ignored) {
            }
        }
    }

    private void ttsHalt() {
        try {
            if (tts != null && ttsReady) tts.stop();
        } catch (Throwable ignored) {
        }
        ttsResolveAll();
    }

    private void ttsShutdown() {
        ttsHalt();
        try {
            if (tts != null) tts.shutdown();
        } catch (Throwable ignored) {
        }
        tts = null;
        ttsReady = false;
        ttsIniting = false;
    }

    private void ttsFinish(String id, String err) {
        PluginCall c;
        synchronized (ttsCalls) {
            c = ttsCalls.remove(id);
        }
        if (c == null) return;
        try {
            if (err == null) c.resolve();
            else c.reject(err);
        } catch (Throwable ignored) {
        }
    }

    private class TtsListener extends UtteranceProgressListener {
        @Override
        public void onStart(String utteranceId) {
        }

        @Override
        public void onDone(String utteranceId) {
            ttsFinish(utteranceId, null);
        }

        @Override
        public void onError(String utteranceId) {
            ttsFinish(utteranceId, "tts-error");
        }

        @Override
        public void onError(String utteranceId, int errorCode) {
            ttsFinish(utteranceId, "tts-error");
        }

        @Override
        public void onStop(String utteranceId, boolean interrupted) {
            ttsFinish(utteranceId, null);
        }
    }

    /* ================= ভয়েস ইনপুট (SpeechRecognizer) ================= */

    @PluginMethod
    public void speechStart(PluginCall call) {
        if (getPermissionState("microphone") != PermissionState.GRANTED) {
            requestPermissionForAlias("microphone", call, "speechPermCallback");
            return;
        }
        doSpeechStart(call);
    }

    @PermissionCallback
    private void speechPermCallback(PluginCall call) {
        if (getPermissionState("microphone") == PermissionState.GRANTED) {
            doSpeechStart(call);
        } else {
            call.reject("not-allowed");
        }
    }

    private void doSpeechStart(final PluginCall call) {
        final String lang = call.getString("lang", "bn-BD");
        speechPartial = Boolean.TRUE.equals(call.getBoolean("partial", false));
        final int max = call.getInt("max", 3);
        final Activity act = getActivity();
        if (act == null) {
            call.reject("no-activity");
            return;
        }
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!SpeechRecognizer.isRecognitionAvailable(getContext())) {
                        call.reject("service-not-allowed");
                        return;
                    }
                    destroyRecognizer();
                    recognizer = SpeechRecognizer.createSpeechRecognizer(getContext());
                    recognizer.setRecognitionListener(new Listener());
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang);
                    i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, speechPartial);
                    i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, max);
                    i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getContext().getPackageName());
                    setBeepMuted(true);
                    recognizer.startListening(i);
                    call.resolve();
                } catch (Throwable t) {
                    setBeepMuted(false);
                    call.reject("audio-capture");
                }
            }
        });
    }

    @PluginMethod
    public void speechStop(final PluginCall call) {
        runOnUi(new Runnable() {
            @Override
            public void run() {
                try {
                    if (recognizer != null) recognizer.stopListening();
                } catch (Throwable ignored) {
                }
                call.resolve();
            }
        });
    }

    @PluginMethod
    public void speechCancel(final PluginCall call) {
        runOnUi(new Runnable() {
            @Override
            public void run() {
                destroyRecognizer();
                call.resolve();
            }
        });
    }

    private void destroyRecognizer() {
        final SpeechRecognizer r = recognizer;
        recognizer = null;
        setBeepMuted(false);
        if (r == null) return;
        Runnable x = new Runnable() {
            @Override
            public void run() {
                try {
                    r.setRecognitionListener(null);
                    r.cancel();
                    r.destroy();
                } catch (Throwable ignored) {
                }
            }
        };
        runOnUi(x);
    }

    private void runOnUi(Runnable r) {
        Activity a = getActivity();
        if (a != null) a.runOnUiThread(r);
        else r.run();
    }

    /** SpeechRecognizer চালু হওয়ার "টুং" শব্দ চাপা দিতে (নিজে যেগুলো মিউট করেছি শুধু সেগুলোই আবার খুলি) */
    private void setBeepMuted(boolean mute) {
        try {
            AudioManager am = (AudioManager) getContext().getSystemService(Context.AUDIO_SERVICE);
            if (am == null) return;
            int[] streams = {AudioManager.STREAM_NOTIFICATION, AudioManager.STREAM_SYSTEM};
            if (mute) {
                for (int s : streams) {
                    try {
                        if (Build.VERSION.SDK_INT >= 23 && !am.isStreamMute(s) && !mutedStreams.contains(s)) {
                            am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0);
                            mutedStreams.add(s);
                        }
                    } catch (Throwable ignored) {
                    }
                }
            } else {
                for (int s : new ArrayList<>(mutedStreams)) {
                    try {
                        am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0);
                    } catch (Throwable ignored) {
                    }
                }
                mutedStreams.clear();
            }
        } catch (Throwable ignored) {
        }
    }

    private class Listener implements RecognitionListener {
        @Override
        public void onReadyForSpeech(Bundle params) {
            // কিছুক্ষণ পরে মিউট ছাড়ি (টুং শব্দ ততক্ষণে শেষ)
            if (getActivity() != null) {
                getActivity().getWindow().getDecorView().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        setBeepMuted(false);
                    }
                }, 450);
            } else {
                setBeepMuted(false);
            }
            notifyListeners("speechReady", new JSObject());
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
        }

        @Override
        public void onError(int error) {
            setBeepMuted(false);
            String e;
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                    e = "no-speech";
                    break;
                case SpeechRecognizer.ERROR_NETWORK:
                case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                case SpeechRecognizer.ERROR_SERVER:
                    e = "network";
                    break;
                case SpeechRecognizer.ERROR_AUDIO:
                    e = "audio-capture";
                    break;
                case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                    e = "not-allowed";
                    break;
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                    e = "busy";
                    break;
                case SpeechRecognizer.ERROR_CLIENT:
                    e = "aborted";
                    break;
                case 12: // ERROR_LANGUAGE_NOT_SUPPORTED
                case 13: // ERROR_LANGUAGE_UNAVAILABLE
                    e = "language-not-supported";
                    break;
                default:
                    e = "unknown";
            }
            JSObject o = new JSObject();
            o.put("error", e);
            o.put("code", error);
            notifyListeners("speechError", o);
        }

        @Override
        public void onResults(Bundle results) {
            setBeepMuted(false);
            sendResults(results, true);
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            if (speechPartial) sendResults(partialResults, false);
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    }

    private void sendResults(Bundle b, boolean isFinal) {
        if (b == null) return;
        ArrayList<String> list = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        float[] conf = b.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);
        if (list == null || list.isEmpty()) return;
        JSArray arr = new JSArray();
        JSArray cs = new JSArray();
        for (int i = 0; i < list.size(); i++) {
            arr.put(list.get(i));
            try {
                cs.put(conf != null && i < conf.length ? (double) conf[i] : 0.9d);
            } catch (Throwable t) {
                cs.put(0.9d);
            }
        }
        JSObject o = new JSObject();
        o.put("matches", arr);
        o.put("confidence", cs);
        o.put("isFinal", isFinal);
        notifyListeners("speechResult", o);
    }

    /* ================= বায়োমেট্রিক / স্ক্রিন-লক ================= */

    @PluginMethod
    public void bioAvailable(PluginCall call) {
        boolean ok = false;
        try {
            KeyguardManager km = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
            ok = km != null && km.isDeviceSecure();
        } catch (Throwable ignored) {
        }
        JSObject r = new JSObject();
        r.put("available", ok);
        call.resolve(r);
    }

    @PluginMethod
    public void bioAuth(final PluginCall call) {
        final String title = call.getString("title", "পরিচয় যাচাই");
        final String sub = call.getString("subtitle", "");
        if (Build.VERSION.SDK_INT >= 30) {
            runOnUi(new Runnable() {
                @Override
                public void run() {
                    try {
                        BiometricPrompt.Builder b = new BiometricPrompt.Builder(getContext())
                                .setTitle(title)
                                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK
                                        | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
                        if (sub.length() > 0) b.setSubtitle(sub);
                        BiometricPrompt p = b.build();
                        p.authenticate(new CancellationSignal(), getContext().getMainExecutor(),
                                new BiometricPrompt.AuthenticationCallback() {
                                    @Override
                                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                                        JSObject r = new JSObject();
                                        r.put("ok", true);
                                        call.resolve(r);
                                    }

                                    @Override
                                    public void onAuthenticationError(int errorCode, CharSequence errString) {
                                        call.reject(String.valueOf(errString), String.valueOf(errorCode));
                                    }
                                });
                    } catch (Throwable t) {
                        keyguardAuth(call, title, sub);
                    }
                }
            });
        } else {
            keyguardAuth(call, title, sub);
        }
    }

    private void keyguardAuth(PluginCall call, String title, String sub) {
        try {
            KeyguardManager km = (KeyguardManager) getContext().getSystemService(Context.KEYGUARD_SERVICE);
            Intent i = km == null ? null : km.createConfirmDeviceCredentialIntent(title, sub);
            if (i == null) {
                call.reject("no-lock");
                return;
            }
            startActivityForResult(call, i, "keyguardResult");
        } catch (Throwable t) {
            call.reject("failed");
        }
    }

    @ActivityCallback
    private void keyguardResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() == Activity.RESULT_OK) {
            JSObject r = new JSObject();
            r.put("ok", true);
            call.resolve(r);
        } else {
            call.reject("cancelled");
        }
    }

    /* ================= ফাইল সেভ / শেয়ার ================= */

    @PluginMethod
    public void saveFile(PluginCall call) {
        String name = call.getString("name", "file.bin");
        String mime = call.getString("mime", "application/octet-stream");
        String data = call.getString("data", "");
        String mode = call.getString("mode", "save"); // save | open | share
        try {
            byte[] bytes = Base64.decode(data, Base64.DEFAULT);
            Context c = getContext();
            Uri uri;
            String where;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentResolver cr = c.getContentResolver();
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, mime);
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Jonaki");
                uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (uri == null) throw new Exception("insert failed");
                OutputStream os = cr.openOutputStream(uri);
                if (os == null) throw new Exception("stream failed");
                try {
                    os.write(bytes);
                } finally {
                    os.close();
                }
                where = "Download/Jonaki";
            } else {
                File dir = c.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) dir = c.getFilesDir();
                if (!dir.exists()) dir.mkdirs();
                File f = new File(dir, name);
                FileOutputStream os = new FileOutputStream(f);
                try {
                    os.write(bytes);
                } finally {
                    os.close();
                }
                uri = Uri.fromFile(f);
                where = f.getParent();
            }
            if (Build.VERSION.SDK_INT >= 29) {
                if ("open".equals(mode)) {
                    Intent v = new Intent(Intent.ACTION_VIEW);
                    v.setDataAndType(uri, mime);
                    v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        c.startActivity(v);
                    } catch (Throwable ignored) {
                    }
                } else if ("share".equals(mode)) {
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType(mime);
                    s.putExtra(Intent.EXTRA_STREAM, uri);
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    Intent ch = Intent.createChooser(s, name);
                    ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    c.startActivity(ch);
                }
            }
            JSObject r = new JSObject();
            r.put("uri", uri.toString());
            r.put("where", where);
            call.resolve(r);
        } catch (Throwable t) {
            call.reject("save failed: " + t.getMessage());
        }
    }

    @PluginMethod
    public void shareText(PluginCall call) {
        try {
            String text = call.getString("text", "");
            String url = call.getString("url", "");
            String title = call.getString("title", "");
            StringBuilder sb = new StringBuilder();
            if (text.length() > 0) sb.append(text);
            if (url.length() > 0) {
                if (sb.length() > 0) sb.append("\n");
                sb.append(url);
            }
            Intent s = new Intent(Intent.ACTION_SEND);
            s.setType("text/plain");
            if (title.length() > 0) s.putExtra(Intent.EXTRA_SUBJECT, title);
            s.putExtra(Intent.EXTRA_TEXT, sb.toString());
            Intent ch = Intent.createChooser(s, title.length() > 0 ? title : "শেয়ার");
            ch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(ch);
            call.resolve();
        } catch (Throwable t) {
            call.reject("share failed");
        }
    }

    /* ================= ক্লিপবোর্ড ================= */

    @PluginMethod
    public void clipWrite(final PluginCall call) {
        final String text = call.getString("text", "");
        runOnUi(new Runnable() {
            @Override
            public void run() {
                try {
                    ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm == null) {
                        call.reject("no clipboard");
                        return;
                    }
                    if (text.length() == 0) {
                        if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip();
                        else cm.setPrimaryClip(ClipData.newPlainText("", ""));
                    } else {
                        ClipData cd = ClipData.newPlainText("text", text);
                        if (Build.VERSION.SDK_INT >= 33) {
                            PersistableBundle pb = new PersistableBundle();
                            pb.putBoolean("android.content.extra.IS_SENSITIVE", true);
                            cd.getDescription().setExtras(pb);
                        }
                        cm.setPrimaryClip(cd);
                    }
                    call.resolve();
                } catch (Throwable t) {
                    call.reject("clip failed");
                }
            }
        });
    }

    @PluginMethod
    public void clipRead(final PluginCall call) {
        runOnUi(new Runnable() {
            @Override
            public void run() {
                try {
                    ClipboardManager cm = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                    String t = "";
                    if (cm != null && cm.hasPrimaryClip()) {
                        ClipData cd = cm.getPrimaryClip();
                        if (cd != null && cd.getItemCount() > 0) {
                            CharSequence cs = cd.getItemAt(0).coerceToText(getContext());
                            if (cs != null) t = cs.toString();
                        }
                    }
                    JSObject r = new JSObject();
                    r.put("text", t);
                    call.resolve(r);
                } catch (Throwable e) {
                    call.reject("clip failed");
                }
            }
        });
    }

    /* ================= স্ক্রিন চালু রাখা ================= */

    @PluginMethod
    public void keepAwake(final PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        runOnUi(new Runnable() {
            @Override
            public void run() {
                try {
                    Activity a = getActivity();
                    if (a != null) {
                        if (on) a.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                        else a.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    }
                } catch (Throwable ignored) {
                }
                call.resolve();
            }
        });
    }

    /* ================= অটোফিল ================= */

    @PluginMethod
    public void afSync(PluginCall call) {
        try {
            String json = call.getString("entries", "[]");
            AutofillStore.save(getContext(), json);
            call.resolve();
        } catch (Throwable t) {
            call.reject("sync failed");
        }
    }

    @PluginMethod
    public void afClear(PluginCall call) {
        AutofillStore.clear(getContext());
        call.resolve();
    }

    @PluginMethod
    public void afDisable(PluginCall call) {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                AutofillManager afm = getContext().getSystemService(AutofillManager.class);
                if (afm != null) afm.disableAutofillServices();
            }
        } catch (Throwable ignored) {
        }
        call.resolve();
    }

    @PluginMethod
    public void afEnable(PluginCall call) {
        if (Build.VERSION.SDK_INT < 26) {
            call.reject("unsupported");
            return;
        }
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE,
                    Uri.parse("package:" + getContext().getPackageName()));
            startActivityForResult(call, i, "afEnableResult");
        } catch (Throwable t) {
            call.reject("unsupported");
        }
    }

    @ActivityCallback
    private void afEnableResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        boolean en = false;
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                AutofillManager afm = getContext().getSystemService(AutofillManager.class);
                en = afm != null && afm.hasEnabledAutofillServices();
            }
        } catch (Throwable ignored) {
        }
        JSObject r = new JSObject();
        r.put("enabled", en);
        call.resolve(r);
    }
}
