package __APP_ID__;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.KeyguardManager;
import android.app.assist.AssistStructure;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.service.autofill.Dataset;
import android.view.autofill.AutofillId;
import android.view.autofill.AutofillManager;
import android.view.autofill.AutofillValue;
import android.widget.RemoteViews;
import android.widget.Toast;

import java.util.List;

/**
 * অটোফিলের আগে স্ক্রিন-লক দিয়ে যাচাই; একাধিক মিল থাকলে বেছে নেওয়ার তালিকা দেখায়।
 */
public class AutofillAuthActivity extends Activity {

    private static final int RC_LOCK = 71;

    private String entryId;
    private AutofillId userId;
    private AutofillId passId;

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent in = getIntent();
        entryId = in.getStringExtra("entry");
        try {
            userId = in.getParcelableExtra("user");
            passId = in.getParcelableExtra("pass");
        } catch (Throwable t) {
            userId = null;
            passId = null;
        }
        if (userId == null && passId == null) {
            cancel();
            return;
        }
        try {
            KeyguardManager km = (KeyguardManager) getSystemService(KEYGUARD_SERVICE);
            if (km != null && km.isDeviceSecure()) {
                Intent li = km.createConfirmDeviceCredentialIntent(
                        "কী-ফ্লো অটোফিল", "লগইন তথ্য বসাতে স্ক্রিন-লক দিয়ে যাচাই করুন");
                if (li != null) {
                    startActivityForResult(li, RC_LOCK);
                    return;
                }
            }
        } catch (Throwable ignored) {
        }
        proceed();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == RC_LOCK) {
            if (res == RESULT_OK) proceed();
            else cancel();
        }
    }

    private void proceed() {
        final List<AutofillStore.Entry> all = AutofillStore.load(this);
        if (all.isEmpty()) {
            Toast.makeText(this, "কী-ফ্লোতে সংরক্ষিত লগইন নেই", Toast.LENGTH_SHORT).show();
            cancel();
            return;
        }
        if (entryId != null) {
            for (AutofillStore.Entry e : all) {
                if (entryId.equals(e.id)) {
                    done(e);
                    return;
                }
            }
            cancel();
            return;
        }
        String[] labels = new String[all.size()];
        for (int i = 0; i < labels.length; i++) {
            AutofillStore.Entry e = all.get(i);
            String t = e.title.length() > 0 ? e.title : AutofillStore.hostOf(e.url);
            labels[i] = e.user.length() > 0 ? t + "\n" + e.user : t;
        }
        new AlertDialog.Builder(this)
                .setTitle("কী-ফ্লো — লগইন বাছুন")
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        done(all.get(which));
                    }
                })
                .setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface d) {
                        cancel();
                    }
                })
                .show();
    }

    @SuppressWarnings("deprecation")
    private void done(AutofillStore.Entry e) {
        try {
            RemoteViews rv = new RemoteViews(getPackageName(), R.layout.autofill_item);
            rv.setTextViewText(R.id.af_title, e.title.length() > 0 ? e.title : AutofillStore.hostOf(e.url));
            rv.setTextViewText(R.id.af_sub, e.user);
            Dataset.Builder db = new Dataset.Builder(rv);
            if (userId != null) db.setValue(userId, AutofillValue.forText(e.user));
            if (passId != null) db.setValue(passId, AutofillValue.forText(e.pass));
            Intent reply = new Intent();
            reply.putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, db.build());
            setResult(RESULT_OK, reply);
        } catch (Throwable t) {
            setResult(RESULT_CANCELED);
        }
        finish();
    }

    private void cancel() {
        setResult(RESULT_CANCELED);
        finish();
    }
}
